import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router, NavigationEnd } from '@angular/router';
import { LoanService } from '../../core/services/loan.service';
import { Loan, LoanStatus } from '../../models/loan.model';
import { filter } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-loan-list',
  templateUrl: './loan-list.html',
  styleUrls: ['./loan-list.css'],
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule]
})
export class LoanListComponent implements OnInit, OnDestroy {
  loans: Loan[] = [];
  loading = false;
  page = 0;
  size = 10;
  totalPages = 0; // ✅ ADD THIS
  totalElements = 0; // ✅ ADD THIS
  statusFilter?: LoanStatus;
  isAdmin = false;
  
  private routerSubscription?: Subscription;

  constructor(
    private loanService: LoanService,
    private router: Router,
    private route: ActivatedRoute   
  ) {}

  ngOnInit() {
    this.isAdmin = localStorage.getItem('role') === 'ADMIN';
    // 🔥 READ STATUS FILTER FROM DASHBOARD STAT CARDS
this.route.queryParams.subscribe(params => {
  const status = params['status'];

  if (status) {
    this.statusFilter = status as LoanStatus;
    this.page = 0; // reset pagination on filter change
  } else {
    this.statusFilter = undefined;
  }
});

    this.loadLoans();

    // Reload loans when navigating to this route
    this.routerSubscription = this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        if (event.url.startsWith('/dashboard/loans')) {
          console.log('🔄 Navigated to loans list, reloading...');
          this.loadLoans();
        }
      });
  }

  ngOnDestroy() {
    this.routerSubscription?.unsubscribe();
  }

  loadLoans() {
    this.loading = true;
    console.log('📥 Loading loans... Page:', this.page);
    
    this.loanService.getLoans(this.page, this.size, this.statusFilter).subscribe({
      next: (res) => {
        console.log('✅ Loans loaded:', res);
        this.loans = res.content;
        this.totalPages = res.totalPages; // ✅ ADD THIS
        this.totalElements = res.totalElements; // ✅ ADD THIS
        this.loading = false;
      },
      error: (err) => {
        console.error('❌ Error loading loans:', err);
        this.loading = false;
      }
    });
  }

  // ✅ ADD THESE PAGINATION METHODS
  nextPage() {
    if (this.page < this.totalPages - 1) {
      this.page++;
      this.loadLoans();
    }
  }

  previousPage() {
    if (this.page > 0) {
      this.page--;
      this.loadLoans();
    }
  }

  openLoanDetails(loanId: string) {
    this.router.navigate(['/dashboard/loans', loanId]);
  }

  canEditLoan(loan: Loan): boolean {
    return !this.isAdmin && loan.status === LoanStatus.DRAFT;
  }

  submitLoan(id: string) {
    this.loanService.submitLoan(id).subscribe({
      next: () => {
        console.log('✅ Loan submitted successfully');
        this.loadLoans();
      },
      error: (err) => console.error('❌ Submit failed:', err)
    });
  }

  editLoan(loan: Loan) {
    this.router.navigate(['/dashboard/loans', loan.id, 'edit']);
  }

  markUnderReview(id: string) {
    this.loanService.markUnderReview(id).subscribe({
      next: () => this.loadLoans(),
      error: (err) => console.error(err)
    });
  }

  approveLoan(id: string) {
    this.loanService.approveLoan(id).subscribe({
      next: () => this.loadLoans(),
      error: (err) => console.error(err)
    });
  }

  rejectLoan(id: string, reason: string) {
    this.loanService.rejectLoan(id, reason).subscribe({
      next: () => this.loadLoans(),
      error: (err) => console.error(err)
    });
  }

  deleteLoan(id: string) {
    const confirmDelete = confirm(
      'Are you sure you want to delete this loan? This will mark it as deleted.'
    );

    if (!confirmDelete) return;

    this.loanService.deleteLoan(id).subscribe({
      next: () => {
        this.loans = this.loans.filter(loan => loan.id !== id);
        alert('Loan deleted successfully!');
      },
      error: (err: any) => {
        console.error('Delete loan failed', err);
        alert('Failed to delete loan.');
      }
    });
  }

  confirmSubmit(id: string) {
    if (confirm('Submit this loan?')) this.submitLoan(id);
  }

  confirmReview(id: string) {
    if (confirm('Move this loan to review?')) this.markUnderReview(id);
  }

  confirmApprove(id: string) {
    if (confirm('Approve this loan?')) this.approveLoan(id);
  }

  confirmReject(id: string) {
    const reason = prompt('Enter rejection reason:');
    if (reason) this.rejectLoan(id, reason);
  }

  confirmDelete(id: string) {
    if (confirm('Delete this loan?')) this.deleteLoan(id);
  }
}