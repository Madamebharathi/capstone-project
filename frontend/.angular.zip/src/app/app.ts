import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';


@Component({
  selector: 'app-root',
  standalone: true,           // ✅ standalone component
  imports: [RouterOutlet],    // include RouterOutlet here
  templateUrl: './app.html',
  styleUrls: ['./app.css']    // fix typo
})
export class App {
  protected readonly title = signal('loan-approval-ui');
}
