export interface User {
  email: string;
  role: 'USER' | 'ADMIN';
}
