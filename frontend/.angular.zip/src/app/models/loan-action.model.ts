export interface LoanAction {
  action: string;
  performedBy: string;
  performedAt: string;
}
