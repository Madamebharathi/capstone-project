export interface LoginRequestModel {
    email: string;
  password: string;
}
