export interface Financials {
  revenue: number;
  ebitda: number;
  rating: string;
}
